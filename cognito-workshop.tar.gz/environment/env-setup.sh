#!/bin/bash

#########################
### Environment Setup ###
#########################


### Check if there are existing folders - if so, move them to an "_old" folder

if [ -d "$HOME/environment/cognito-web/" ]; then
  [ ! -d "$HOME/environment/_old/" ] && mkdir $HOME/environment/_old
  mv $HOME/environment/cognito-web $HOME/environment/_old/cognito-web
fi

if [ -d "$HOME/environment/cognito-lambdas/" ]; then
  [ ! -d "$HOME/environment/_old/" ] && mkdir $HOME/environment/_old
  mv $HOME/environment/cognito-lambdas $HOME/environment/_old/cognito-lambdas
fi


### Installations

#### jq
echo "Installing jq..."
wget -O jq https://github.com/stedolan/jq/releases/download/jq-1.7/jq-linux64
chmod +x ./jq
sudo cp jq /usr/bin
rm jq
echo "Done"

#### AWS CLI
echo "Installing AWS CLI..."
sudo yum remove -y awscli
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
rm -rf aws
rm awscliv2.zip
echo "Done"

#### AWS SAM
echo "Installing AWS SAM CLI..."
curl -LJ "https://github.com/aws/aws-sam-cli/releases/latest/download/aws-sam-cli-linux-x86_64.zip" -o "aws-sam-cli.zip"
unzip aws-sam-cli.zip -d sam-installation
sudo ./sam-installation/install --update
rm -rf sam-installation
rm aws-sam-cli.zip
echo "Done"

#### ESBuild
echo "Installing ESBuild..."
npm i -g esbuild
echo "Done"

### Boto3
echo "Installing Boto3..."
pip3 install boto3
echo "Done"

### Creating files and folders
echo "Creating files and folders..."
cd $HOME/environment/
mkdir -p cognito-web/{web-app/authn,web-app/public,web-ui-js}
touch cognito-web/web-app/{app.js,package.json,run.sh,authn/app.js} cognito-web/web-app/public/{cognito-sdk.html,signup.html,signin.html}
touch cognito-web/template.yaml cognito-web/web-ui-js/{cognito-sdk.js,signup.js,signin.js,helpers.js,cognito-env.js,cognito-env-tmpl.js,package.json}
curl -o cognito-web/web-app/public/favicon.ico https://a0.awsstatic.com/libra-css/images/site/fav/favicon.ico
mkdir -p cognito-lambdas/{ApiGWAuthZ,ApiGWAuthZ/authz-lambda,CreateAuthChallenge,DefineAuthChallenge,MigrateUser,PreToken,VerifyAuthChallenge}
for folder in cognito-lambdas/*; do touch "$folder/app.mjs"; done
mv cognito-lambdas/ApiGWAuthZ/app.mjs cognito-lambdas/ApiGWAuthZ/authz-lambda/app.py
touch cognito-lambdas/template.yaml cognito-lambdas/ApiGWAuthZ/{template.yaml,authz-lambda/requirements.txt}
echo "Done"


### Adding code
echo "Adding initial code..."

cat >$HOME/environment/cognito-web/template.yaml <<'EOL'
AWSTemplateFormatVersion: '2010-09-09'
Transform: AWS::Serverless-2016-10-31
Description: >
  cognito-webapp
  Amazon Cognito Workshop
  
Resources:
  CognitoWebApp:
    Type: AWS::Serverless::Function
    Properties:
      FunctionName: !Sub ${AWS::StackName}-CognitoWebApp
      CodeUri: web-app/
      Handler: run.sh
      Runtime: nodejs18.x
      MemorySize: 1024
      Timeout: 3
      Architectures:
        - x86_64
      Environment:
        Variables:
          AWS_LAMBDA_EXEC_WRAPPER: /opt/bootstrap
          RUST_LOG: info
      Layers:
        - !Sub arn:aws:lambda:${AWS::Region}:753240598075:layer:LambdaAdapterLayerX86:17
      Events:
        RootPath:
          Type: Api
          Properties:
            Path: /
            Method: ANY
        AnyPath:
          Type: Api
          Properties:
            Path: /{proxy+}
            Method: ANY

Outputs:
  CognitoWebAppURL:
    Description: "Cognito Workshop Web App URL"
    Value: !Sub "https://${ServerlessRestApi}.execute-api.${AWS::Region}.${AWS::URLSuffix}/Prod/"
EOL

cat >$HOME/environment/cognito-web/web-app/run.sh <<'EOL'
#!/bin/bash

node app.js
EOL

cat >$HOME/environment/cognito-web/web-app/package.json <<'EOL'
{
  "name": "cognito-ws-be",
  "version": "1.0.0",
  "description": "Amazon Cognito Workshop Backend",
  "main": "app.js",
  "type": "module",
  "license": "MIT",
  "dependencies": {
    "express": "^4.18.2",
    "base64-arraybuffer": "^1.0.2",
    "fido2-lib": "^3.4.1"
  }
}
EOL

cat >$HOME/environment/cognito-web/web-ui-js/package.json <<'EOL'
{
  "name": "cognito-ws-fe",
  "version": "1.0.0",
  "description": "Amazon Cognito Workshop Front-End",
  "main": "app.js",
  "type": "module",
  "license": "MIT",
  "dependencies": {
    "@aws-sdk/client-s3": "^3.418.0",
    "@aws-sdk/credential-providers": "^3.418.0",
    "amazon-cognito-identity-js": "^6.3.6",
    "axios": "^1.5.0",
    "base64-arraybuffer": "^1.0.2",
    "qrcode": "^1.5.3"
  }
}
EOL

cat >$HOME/environment/cognito-web/web-ui-js/cognito-env-tmpl.js <<'EOL'
const POOL_DATA = {
  UserPoolId: "${WS_USER_POOL_ID}",
  IdentityPoolId: "${WS_IDENTITY_POOL_ID}",
  ClientId: "${WS_USER_POOL_CLIENT_ID}",
  Region: "${WS_REGION}",
  ServiceEndpoint: "https://${WS_MOCK_API_ID}.execute-api.${WS_REGION}.amazonaws.com/Prod/pets"
};
export { POOL_DATA }
EOL

cat >$HOME/environment/cognito-web/web-app/authn/app.js <<'EOL'
import express from 'express';
const router = express.Router();
export default router;
EOL

cat >$HOME/environment/cognito-web/web-app/app.js <<'EOL'
import express from 'express';
import authn from './authn/app.js';

const app = express();
const port = process.env['PORT'] || 8080;


app.use(express.json());
app.use(express.static('public'));


app.use((req, res, next) => {
  if (req.get('x-forwarded-proto') &&
      (req.get('x-forwarded-proto')).split(',')[0] !== 'https') {
    return res.redirect(301, `https://${req.get('host')}`);
  }
  req.schema = 'https';
  next();
});


app.get('/', (req, res) => {
  res.send('Amazon Cognito Workshop');
});


app.get('/callback', (req, res) => {
  res.type('html');
  res.status(200);
  res.send(`
    <!DOCTYPE html><html><body onload="zFunc()"><script>
    function zFunc() { if (window.location.hash.length > 0) window.location.replace(window.location.href.replace('#', '?')); }
    </script><pre style="background-color:#C0C0C0;padding:1em;white-space:pre-wrap;overflow-wrap:break-word"><code>${JSON.stringify(req.query, null, 2)}</code></pre></body></html>
  `);
});


app.use('/authn', authn);


app.listen(port);
EOL

cat >$HOME/environment/cognito-lambdas/template.yaml <<'EOL'
AWSTemplateFormatVersion: '2010-09-09'
Transform: AWS::Serverless-2016-10-31
Description: >
  cognito-lambdas
  SAM Template for cognito-lambdas

Globals:
  Function:
    Handler: app.lambdaHandler
    Runtime: nodejs18.x
    MemorySize: 1024
    Timeout: 30
    Tracing: Active
    Architectures:
      - x86_64

Parameters:
  UserPoolArn:
    Type: String
    Default: ''
  UserPoolId:
    Type: String
    Default: ''
  ClientId:
    Type: String
    Default: ''

Resources:
EOL

echo "Done"


### Installing Node.js dependencies
echo "Installing Node.js dependencies..."
cd $HOME/environment/cognito-web/web-app/
npm i
cd $HOME/environment/cognito-web/web-ui-js/
npm i
echo "Done"
