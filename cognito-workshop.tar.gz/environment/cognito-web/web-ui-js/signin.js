import { encode } from 'base64-arraybuffer';
import { CognitoUserPool, CognitoUser, AuthenticationDetails } from 'amazon-cognito-identity-js';
import { POOL_DATA } from './cognito-env.js';
import { alert, coerceToArrayBuffer } from './helpers.js';


let cognitoUser;
const username = document.getElementById('floatingUsername') || {};

function signIn () {
  const userPool = new CognitoUserPool(POOL_DATA);
  const authenticationDetails = new AuthenticationDetails({ Username: username.value });

  cognitoUser = new CognitoUser({ Username: username.value, Pool: userPool });
  cognitoUser.setAuthenticationFlowType('CUSTOM_AUTH');
  cognitoUser.initiateAuth(authenticationDetails, authCallback);
}

let authCallback = {
  onSuccess: function (result) {
    const accessToken = result.getAccessToken().getJwtToken();
    const idToken = result.idToken.jwtToken;
    alert('Sign In successful!', 'success');
    localStorage.setItem('idToken', idToken);
    localStorage.setItem('accessToken', accessToken);
    console.log('Access Token:', accessToken);
    console.log('ID Token:', idToken);
  },

  onFailure: function (err) {
    alert('There was an issue with signing you in!', 'danger');
    console.log('err:', err);
  },

  customChallenge: async function (challengeParameters) {
    let signinOptions = {
      challenge: coerceToArrayBuffer(challengeParameters.challenge, 'challenge'),
      timeout: 1800000,
      rpId: window.location.hostname,
      userVerification: 'preferred',
      allowCredentials: [
        {
          id: coerceToArrayBuffer(challengeParameters.credId, 'id'),
          type: 'public-key',
          transports: ['ble', 'nfc', 'usb', 'internal']
        }
      ]
    };
  
    console.log('signinOptions', signinOptions);
  
    const cred = await navigator.credentials.get({
      publicKey: signinOptions
    });
    
    let credential = {};
    if (cred.response) credential.response = {
      clientDataJSON: encode(cred.response.clientDataJSON),
      authenticatorData: encode(cred.response.authenticatorData),
      signature: encode(cred.response.signature),
      userHandle: encode(cred.response.userHandle)
    };
    
    cognitoUser.sendCustomChallengeAnswer(JSON.stringify(credential), this);
  }
};

// Using the acquired token to test access to the protected API
async function APITest () {
  console.log ('Trying to get an authenticated response from the server.');
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': localStorage.getItem('idToken') || ''
  };
  
  try {
    const res = await fetch(POOL_DATA.ServiceEndpoint + '/pets', {
      method: 'GET',
      headers: headers
    });
    
    const resJSON = await res.json();
    console.log('API Result', resJSON);
    alert('API Result:<br />' + JSON.stringify(resJSON, null, 2), 'info');
  } catch(e) {
    console.log('API Error:', e.message);
    alert('API Error:<br />' + e.message, 'danger');
  }
}

// Configure some listeners when the DOM is ready
(() => {
  'use strict'
  const form1 = document.getElementById('zform1') || {};
  const testButton = document.getElementById('testButton') || {};
  const clearButton = document.getElementById('clearButton') || {};
  
  form1.addEventListener('submit', event => {
    form1.classList.add('was-validated');
    event.preventDefault();
    event.stopPropagation();
    if (form1.checkValidity()) signIn();
  }, false);
  
  testButton.addEventListener('click', event => {
    event.preventDefault();
    event.stopPropagation();
    APITest();
  }, false);
  
  clearButton.addEventListener('click', event => {
    event.preventDefault();
    event.stopPropagation();
    localStorage.clear();
    alert('Tokens Cleared', 'success');
  }, false);
})()

