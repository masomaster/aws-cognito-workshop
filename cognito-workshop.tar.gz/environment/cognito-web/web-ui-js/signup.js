import { encode, decode } from 'base64-arraybuffer';
import { CognitoUserPool, CognitoUser, CognitoUserAttribute } from 'amazon-cognito-identity-js';
import { POOL_DATA } from './cognito-env.js';
import { _fetch, alert } from './helpers.js';

const userPool = new CognitoUserPool(POOL_DATA);
let globalRegisteredCredentials = '';
let globalRegisteredCredentialsJSON = {};


// Reference to DOM elements
const username = document.getElementById('floatingUsername') || {};
const email = document.getElementById('floatingEmail') || {};
const password = document.getElementById('floatingPassword') || {};

// Create credentials using platform or roaming authenticator
async function createCredential() {
  try {
    var credOptionsRequest = {
      attestation: 'none',
      username: username.value,
      name: email.value,
      authenticatorSelection: {
        authenticatorAttachment: ['platform','cross-platform'],
        userVerification: 'preferred',
        requireResidentKey: false
      }
    };
    
    let credOptions = await _fetch('/Prod/authn/createCredRequest', credOptionsRequest);
    let challenge = credOptions.challenge;
    
    credOptions.user.id = decode(credOptions.user.id);
    credOptions.challenge = decode(credOptions.challenge);
    
    console.log('Starting...');
    console.log(credOptions.rp);
    console.log(credOptions.user);
    
    // Create the credentials using an available authenticator
    const cred = await navigator.credentials.create({
      publicKey: credOptions
    });
    console.log('cred', cred);
    
    // Parse credentials response to extract id and public-key (needed to register the user in Cognito)
    const credential = {
      id: cred.id,
      rawId: encode(cred.rawId),
      type: cred.type,
      challenge: encode(credOptions.challenge)
    };
    
    if (cred.response) {
      const clientDataJSON = encode(cred.response.clientDataJSON);
      const attestationObject = encode(cred.response.attestationObject);
      credential.response = {
        clientDataJSON,
        attestationObject
      };
    }
    
    let credResponse = await _fetch('/Prod/authn/parseCredResponse', credential);
    
    globalRegisteredCredentialsJSON = {
      id: credResponse.credId,
      publicKey: credResponse.publicKey
    };
    globalRegisteredCredentials = JSON.stringify(globalRegisteredCredentialsJSON);
    
    console.log('Registered Credentials', globalRegisteredCredentials);
    
    signUp();
  } catch (e) {console.error(e);}
};

async function signUp() {
  const attrList = [];
  
  const emailAttribute = {
    Name: 'email',
    Value: email.value,
  };
  
  attrList.push(new CognitoUserAttribute(emailAttribute));
  
  var publicKeyCred = btoa(globalRegisteredCredentials);
  var dataPublicKeyCred = { Name: 'custom:publicKeyCred', Value: publicKeyCred };
  
  attrList.push(new CognitoUserAttribute(dataPublicKeyCred));
  
  await userPool.signUp(
    username.value,
    password.value,
    attrList,
    null,
    (err, result) => {
      if (err) {
        console.log('err', err);
        alert(err, 'danger')
        return;
      }
      console.log(result);
      regConfirm()
    }
  );
}

async function regConfirm() {
  const userData = {
    Username: username.value,
    Pool: userPool,
  };
  const cgntUser = new CognitoUser(userData);
  const confCode = prompt('Please enter confirmation code:');

  await cgntUser.confirmRegistration(confCode, true, (err, result) => {
    if (err) {
      alert(err.message, 'danger');
      return;
    }
  
    console.log(result);
    alert('Registration Confirmed.', 'success');
  });
}

// Configure some listeners when the DOM is ready
(() => {
  'use strict'
  const form1 = document.getElementById('zform1');
  
  form1.addEventListener('submit', event => {
    form1.classList.add('was-validated');
    event.preventDefault();
    event.stopPropagation();
    if (form1.checkValidity()) createCredential();
  }, false);
})()

