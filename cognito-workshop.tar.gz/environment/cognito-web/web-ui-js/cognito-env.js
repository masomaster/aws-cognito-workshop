const POOL_DATA = {
  UserPoolId: "us-west-2_aO214H3px",
  IdentityPoolId: "us-west-2:2d1b32cb-e255-4e44-8e25-e2b7c54f9863",
  ClientId: "7n6fvaro0hbkibrnv4ttmcpkq0",
  Region: "us-west-2",
  ServiceEndpoint: "https://q7ciunqce2.execute-api.us-west-2.amazonaws.com/Prod/pets"
};
export { POOL_DATA }
