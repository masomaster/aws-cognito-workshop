import { Buffer } from 'buffer';


// WebAuthN helper
function coerceToArrayBuffer (buf, name) {
  if (typeof buf === "string") {
    buf = buf.replace(/-/g, "+").replace(/_/g, "/");
    buf = Buffer.from(buf, "base64");
  }

  if (buf instanceof Buffer || Array.isArray(buf)) {
    buf = new Uint8Array(buf);
  }

  if (buf instanceof Uint8Array) {
    buf = buf.buffer;
  }

  if (!(buf instanceof ArrayBuffer)) {
    throw new TypeError(`could not coerce '${name}' to ArrayBuffer`);
  }

  return buf;
}


// Helper function to avoid repetitions with fetch
async function _fetch (path, payload) {
  const headers = {'X-Requested-With': 'XMLHttpRequest'};
  if (payload && !(payload instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(payload);
  }
  const res = await fetch(path, {
    method: 'POST',
    credentials: 'same-origin',
    headers: headers,
    body: payload
  });
  if (res.status === 200) {
    return res.json();
  } else {
    const result = await res.json();
    throw result.error;
  }
};


// Displaying important messages on screen
const alert = (message, type) => {
  const wrapper = document.createElement('div');
  const alertPlaceholder = document.getElementById('liveAlertPlaceholder');
  
  wrapper.innerHTML = [
    `<div class="alert alert-${type} alert-dismissible" role="alert">`,
    `   <div>${message}</div>`,
    '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
    '</div>'
  ].join('');
  
  alertPlaceholder.append(wrapper);
}

export {_fetch, alert, coerceToArrayBuffer }

