import express from 'express';
import { Fido2Lib } from 'fido2-lib';
import { coerceToBase64Url, coerceToArrayBuffer } from 'fido2-lib';

const router = express.Router();
const f2l = new Fido2Lib({
  timeout: 30*1000*60,
  rpName: 'WebAuthn With Cognito',
  challengeSize: 32,
  cryptoParams: [-7]
});

router.use(express.json());

/**
 * Respond with required information to call navigator.credential.create()
 **/
router.post('/createCredRequest', async (req, res) => {
  f2l.config.rpId = `${req.get('host')}`;
 
  try {
    const response = await f2l.attestationOptions();
    response.user = {
      displayName: req.body.name,
      id: req.body.username,
      name: req.body.username
    };
    response.challenge = coerceToBase64Url(response.challenge, 'challenge');
    
    response.excludeCredentials = [];
    response.pubKeyCredParams = [];
    const params = [-7, -257];
    for (let param of params) {
      response.pubKeyCredParams.push({type:'public-key', alg: param});
    }
    const as = {};
    const aa = req.body.authenticatorSelection.authenticatorAttachment;
    const rr = req.body.authenticatorSelection.requireResidentKey;
    const uv = req.body.authenticatorSelection.userVerification;
    const cp = req.body.attestation;
    let asFlag = false;

    if (aa && (aa == 'platform' || aa == 'cross-platform')) {
      asFlag = true;
      as.authenticatorAttachment = aa;
    }
    if (rr && typeof rr == 'boolean') {
      asFlag = true;
      as.requireResidentKey = rr;
    }
    if (uv && (uv == 'required' || uv == 'preferred' || uv == 'discouraged')) {
      asFlag = true;
      as.userVerification = uv;
    }
    if (asFlag) {
      response.authenticatorSelection = as;
    }
    if (cp && (cp == 'none' || cp == 'indirect' || cp == 'direct')) {
      response.attestation = cp;
    }

    res.json(response);
  } catch (e) {
    res.status(400).send({ error: e });
  }
});


/**
 * Register user credential
 **/
router.post('/parseCredResponse', async (req, res) => {
  f2l.config.rpId = `${req.get('host')}`;

  try {
    const clientAttestationResponse = { response: {} };
    clientAttestationResponse.rawId = coerceToArrayBuffer(req.body.rawId, 'rawId');
    clientAttestationResponse.response.clientDataJSON = coerceToArrayBuffer(req.body.response.clientDataJSON, 'clientDataJSON');
    clientAttestationResponse.response.attestationObject = coerceToArrayBuffer(req.body.response.attestationObject, 'attestationObject');
    
    let origin = `https://${req.get('host')}`;

    const attestationExpectations = {
      challenge: req.body.challenge,
      origin: origin,
      factor: 'either'
    };

    const regResult = await f2l.attestationResult(clientAttestationResponse, attestationExpectations);

    const credential = {
      credId: coerceToBase64Url(regResult.authnrData.get('credId'), 'credId'),
      publicKey: regResult.authnrData.get('credentialPublicKeyPem'),
      aaguid: coerceToBase64Url(regResult.authnrData.get('aaguid'), 'aaguid'),
      prevCounter: regResult.authnrData.get('counter'),
      flags: regResult.authnrData.get('flags')
    };

    res.json(credential);
  } catch (e) {
    res.status(400).send({ error: e.message });
  }
});


export default router
