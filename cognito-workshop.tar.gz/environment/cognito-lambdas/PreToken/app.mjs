export const lambdaHandler = function(event, context) {

  // Processing user group info
  const userGroup = event.request.groupConfiguration.groupsToOverride;

  //Adding group to id token claim
  event.response = {
    "claimsAndScopeOverrideDetails": {
      "idTokenGeneration": {
        "claimsToAddOrOverride":{
            "department": userGroup.join('')
        }
      },
      "accessTokenGeneration": {
        "scopesToAdd": userGroup
      }
    }
  };

  // Return to Amazon Cognito
  context.done(null, event);
};
