import { CognitoIdentityProviderClient, AdminInitiateAuthCommand, AdminGetUserCommand } from "@aws-sdk/client-cognito-identity-provider";

const authenticateUser = async (username, password) => {
    const cognito = new CognitoIdentityProviderClient();
    console.log("Processing Auth Parameter");
    const params = {
        AuthFlow: process.env.AUTH_FLOW,
        UserPoolId: process.env.USERPOOL_ID,
        ClientId: process.env.CLIENT_ID,
        AuthParameters: {
            USERNAME: username,
            PASSWORD: password
        }
    }

    console.log("Performing Authentication against " + process.env.CLIENT_ID);
    const authCommand = new AdminInitiateAuthCommand(params);
    const authResponse = await cognito.send(authCommand);
    console.log(JSON.stringify(authResponse));

    // extracting ID token to reveal user attributes
    const idToken = authResponse["AuthenticationResult"]["IdToken"];
    console.log(idToken);
    const idTokenPayload = JSON.parse(Buffer.from(idToken.split('.')[1], 'base64').toString());
    console.log(idTokenPayload);

    return idTokenPayload;
}

const lookupUser = async (username) => {
    const cognito = new CognitoIdentityProviderClient();
    console.log("Processing Look up Parameter");
    const params = {
        UserPoolId: process.env.USERPOOL_ID,
        Username: username
    }

    console.log("Performing User look up against " + process.env.USERPOOL_ID);
    const lookupCommand = new AdminGetUserCommand(params);
    const lookupResult = await cognito.send(lookupCommand);
    console.log(lookupResult["UserAttributes"]);

    return lookupResult;
}

const lambdaHandler = async (event) => {
    console.log(event);
    if (event.triggerSource == "UserMigration_Authentication") {
        console.log("Starting User Migration Authentication Flow");

        // Authenticate the user with your existing user directory service
        const user = await authenticateUser(event.userName, event.request.password);
        console.log("Migrating user: " + user["cognito:username"]);

        if (user) {
            console.log("setting up user attributes with email address: " + user["email"]);

            // Migrating user attributes from source User Pool. You can migrate additional attributes as needed.
            event.response.userAttributes = {
                username: user["cognito:username"],
                email: user["email"],
                email_verified: "true",
            };
            event.response.finalUserStatus = "CONFIRMED";
            event.response.messageAction = "SUPPRESS";

            console.log(user["cognito:username"] + " migration successful!");
        }
    }
    else if (event.triggerSource == "UserMigration_ForgotPassword") {

        // Look up the user in your existing user directory service
        const lookupResult = await lookupUser(event.userName);
        if (lookupResult) {
            console.log(event.userName + " found");

            // Setting up user attributes from source User Pool.
            event.response.userAttributes = {
                username: event.userName,
                email: lookupResult["UserAttributes"].find(key => key.Name === 'email').Value,
                email_verified: lookupResult["UserAttributes"].find(key => key.Name === 'email_verified').Value,
            };
            event.response.finalUserStatus = "RESET_REQUIRED";
            event.response.messageAction = "SUPPRESS";

            console.log(lookupResult["UserAttributes"].find(key => key.Name === 'email').Value + " password reset email sent successful! email_verified: " + lookupResult["UserAttributes"].find(key => key.Name === 'email_verified').Value);
        }
    }

    return event;
};

export { lambdaHandler };
