import crypto from 'crypto';

const lambdaHandler = async (event, context) => {
  try {
    console.log(event);
    
    const publicKeyCred = event.request.userAttributes['custom:publicKeyCred'];
    const publicKeyCredJSON = Buffer.from(publicKeyCred, 'base64').toString('ascii');
    const challenge = crypto.randomBytes(64).toString('hex');
    
    console.log(JSON.parse(publicKeyCredJSON));
    
    event.response.publicChallengeParameters = {
      credId: JSON.parse(publicKeyCredJSON).id,
      challenge: challenge
    };
    
    event.response.privateChallengeParameters = { challenge };
    
    console.log('privateChallengeParameters=' + event.response.privateChallengeParameters);
  } catch (err) {
    console.log(err);
    return err;
  }

  return event;
};

export { lambdaHandler };
